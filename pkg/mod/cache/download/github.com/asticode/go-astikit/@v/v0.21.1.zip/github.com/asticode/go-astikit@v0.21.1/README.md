[![GoReportCard](http://goreportcard.com/badge/github.com/asticode/go-astikit)](http://goreportcard.com/report/github.com/asticode/go-astikit)
[![GoDoc](https://godoc.org/github.com/asticode/go-astikit?status.svg)](https://godoc.org/github.com/asticode/go-astikit)
[![Travis](https://travis-ci.org/asticode/go-astikit.svg?branch=master)](https://travis-ci.org/asticode/go-astikit#)
[![Coveralls](https://coveralls.io/repos/github/asticode/go-astikit/badge.svg?branch=master)](https://coveralls.io/github/asticode/go-astikit)

`astikit` is a set of golang helpers that don't require any external dependencies.