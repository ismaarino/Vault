package astikit

import "os"

// Default modes
var (
	DefaultDirMode os.FileMode = 0755
)
